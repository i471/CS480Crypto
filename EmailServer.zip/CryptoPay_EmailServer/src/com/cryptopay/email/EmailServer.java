package com.cryptopay.email;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;

import javax.net.ServerSocketFactory;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

import com.cryptopay.emailSecurity.RandomString;

public class EmailServer {

	private ServerSocket serverSocket;

	EmailServer() throws IOException {
		final int PORT = 25443;
		ServerSocketFactory serverSocketFactory = ServerSocketFactory
				.getDefault();
		serverSocket = serverSocketFactory.createServerSocket(PORT);

	}

	public void run() throws IOException, EmailException,
			ClassNotFoundException {
		Socket socket = null;
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		String emailAddress = null;
		final RandomString randomStr = new RandomString(8, new SecureRandom(),
				RandomString.upper + RandomString.digits);
		while (true) {
			System.out.println("Listening...");
			socket = serverSocket.accept();
			System.out.println("Socket connection success");
			ois = new ObjectInputStream(socket.getInputStream());
			while ((emailAddress = ois.readObject().toString()) == null) {
				Thread.yield();
			}
			System.out.println(emailAddress);
			String code = randomStr.nextString();
			oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject(code);
			sendEmail(emailAddress, code);
		}
	}

	private void sendEmail(String emailAddress, String code)
			throws EmailException {
		String message = "Do not reply to this email. This is my personal email and I haven't looked into spoofing my email address or whatever lmfao\n\nHere is your two-factor-authentication code: "
				+ code;
		SimpleEmail email = establishEmail(emailAddress, message);
		email.send();
	}

	private SimpleEmail establishEmail(String emailAddress, String message)
			throws EmailException {
		// Establish email data
		final String FROM_EMAIL = "alecjstrickland@gmail.com";
		final String APP_PASS = "fiixngaldrecjkuk";
		final String SUBJECT = "2 Factor Authentication Code";
		final String HOST = "smtp.gmail.com";
		final int SMTP_PORT = 465;
		SimpleEmail email = new SimpleEmail();
		email.setStartTLSEnabled(true);
		email.setHostName(HOST);
		email.setSmtpPort(SMTP_PORT);
		email.setAuthenticator(new DefaultAuthenticator(FROM_EMAIL, APP_PASS));
		email.setSSLOnConnect(true);
		email.setFrom(FROM_EMAIL);
		email.setSubject(SUBJECT);
		email.setMsg(message);
		email.addTo(emailAddress);
		return email;
	}
}
