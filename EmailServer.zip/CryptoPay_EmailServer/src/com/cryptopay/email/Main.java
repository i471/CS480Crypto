package com.cryptopay.email;

import java.io.IOException;

import org.apache.commons.mail.EmailException;

public class Main {

	public static void main(String[] args) {
		EmailServer server;
		try {
			server = new EmailServer();
			server.run();
		} catch (IOException | EmailException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
